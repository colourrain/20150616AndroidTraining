import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DOMForXMLParser {

    public static void main(String[] args) {
        
        String CHANELID=args[0];
        HashMap nodeMap = new HashMap();
        // DOM�������Ĺ���ʵ��
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            // ��DOM�������DOM������
            DocumentBuilder db = dbf.newDocumentBuilder();
            // ��ȡXML�ĵ�
            Document doc = db.parse(new File(
                    "./APK/AndroidManifest.xml"));     //C:\Documents and Settings\Administrator\����\ApkTool\APK              
                    //.getResourceAsStream("TableConfig.xml"));
            // �õ�XML�ĵ��ĸ��ڵ�
            doc.normalize(); 
            
            Element root = doc.getDocumentElement();       
            // �õ��ڵ���ӽڵ�����
            NamedNodeMap rootAttrMap=root.getAttributes();           
            for (int i = 0; i < rootAttrMap.getLength(); i++) {
                System.out.println("Root attribute item:  "+rootAttrMap.item(i));
            }
            // �õ��ڵ���ӽڵ��б�
           //AndroidManifest.xml  <meta-data  android:name="UMENG_CHANNEL" 	android:value="17" />
            NodeList meta_nodes =root.getElementsByTagName("meta-data");
            for (int i = 0; i < meta_nodes.getLength(); i++){
                Node meta_node = meta_nodes.item(i);  
                Element meta_node_element=(Element) meta_node; ////���ڵ�����ת��ΪXmlElement���� 
                
                if(meta_node_element.getAttribute("android:name").equals("UMENG_CHANNEL")) 
                {    
                   System.out.println(meta_node.getNodeName());
                   meta_node_element.setAttribute("android:value", CHANELID); //�����ŵ�ֵ
                   NamedNodeMap info = meta_node.getAttributes();  
    
                   for (int j = 0; j < info.getLength(); j++) {  //��ӡmeta-data�ڵ����������ֵ
                        System.out.println("attribute item name:  "+info.item(j).getNodeName());                            
                        System.out.println("attribute item value:  "+info.item(j).getNodeValue()); 
    
                    }
                }
            }
            
            doc2XmlFile(doc,"./APK/AndroidManifest.xml");
              
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }                   
    }
    
    public static boolean doc2XmlFile(Document document,String filename) 
    { 
      boolean flag = true; 
      try 
       { 
            /** ��document�е�����д���ļ���   */ 
             TransformerFactory tFactory = TransformerFactory.newInstance();    
             Transformer transformer = tFactory.newTransformer();  
            /** ���� */ 
            //transformer.setOutputProperty(OutputKeys.ENCODING, "GB2312"); 
             DOMSource source = new DOMSource(document);  
             StreamResult result = new StreamResult(new File(filename));    
             transformer.transform(source, result);  
         }catch(Exception ex) 
         { 
             flag = false; 
             ex.printStackTrace(); 
         } 
        return flag;       
    }

    
    
}
